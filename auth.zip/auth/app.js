const express = require('express');
const db=require('./server.js');
const bodyParser = require('body-parser');
const dotenv=require('dotenv');
const path=require('path');
const port = 7000;
const app = express();
dotenv.config({path:"./.env"});



// const viewDic=path.join(__dirname,'./views' );
// console.log(viewDic)
const publicDir=path.join(__dirname,'./public' );
app.use(express.static(publicDir));





app.set('view engine', 'hbs');
app.use(express.urlencoded({extended:false}));
app.use(express.json());








db.connect((error)=>{
    if(error){
        console.log(error);

    }else{
        console.log("connected with database");
    }

});
app.use('/', require('./routs/pages'));
app.use('/auth', require('./routs/auth'));
app.use('/loginAuth', require('./routs/loginAuth.js'));












app.listen(port);