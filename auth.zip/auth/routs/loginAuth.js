const express=require('express');
const db=require("../server");
const router=express.Router();
const authController=require('../controllers/loginAuth');

router.post('/login', authController.login);
module.exports=router;