const db=require("../server");
const jwt=require('jsonwebtoken');
const bcrypt=require('bcryptjs');

exports.register=(req,res)=>{
    console.log(req.body);
    const {name, email, password, conpassword}=req.body;
    db.query("select email from users where email=?",[email], async (error, results)=>{
 if(error){
    console.log(error)
 }
 
 if(results.length > 0){
    return res.render('register', {
        message:"This email is already taken"

    });

 }
 else if(password!=conpassword){
    return res.render('register', {
        message:"The password and confirm password value is not match"

    });
 }

 let hashedPasword=await bcrypt.hash(password, 8);
 console.log(hashedPasword);

 db.query("insert into users set?",{name:name,email:email,password:hashedPasword},(error,results)=>{
    if(error){
        console.log(error);

    }else{
        console.log(results)
        return res.render('register', {
            message:"User is registered"
    
        });
        
    }

 });
    });
   
    

}