const db = require("../server");
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

exports.login = (req, res) => {
    const { email, password } = req.body;
    console.log(req.body);

    db.query("SELECT * FROM users WHERE email = ?", [email], async (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).json({ error: 'Internal Server Error' });
        }

        if (results.length === 0) {
            return res.render('login', {
                message: "Invalid email or password"
            });
        }

        const user = results[0];
        console.log('Fetched user:', user);

        // Compare the provided password with the hashed password in the database
        const isPasswordMatch = user.Password && password ?
            await bcrypt.compare(password, user.Password) : false;

        if (!isPasswordMatch) {
            return res.render('login', {
                message: "Invalid email or password"
            });
        }

        // If the email and password are correct, generate a token (you may use JWT for this)
        const token = jwt.sign({ userId: user.id }, 'your_secret_key', { expiresIn: '1h' });
        console.log(token);

        // You can store the token in a cookie or send it in the response as needed
        res.cookie('token', token, { httpOnly: true });

        // Redirect or respond with success message as per your requirement
        // res.render("/userprofile");
        res.status(200).json({ message: 'Login successful', user });
    });
};